﻿using Microsoft.AspNetCore.Mvc;

namespace Lab2.Controllers
{
    public class TodoController1 : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
