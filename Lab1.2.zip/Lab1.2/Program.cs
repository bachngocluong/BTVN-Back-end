﻿// Bạch Ngọc Lương - CNTT1710
//B1: Viết một hàm để tính tổng của tất cả các số chẵn trong một mảng.
/*using System; 
using System.Text; // Để sử dụng Encoding.UTF8
class Program
{
    static int SumEvenNumbers(int[] arr)
    {
        int sum = 0;
        foreach (int number in arr)
        {
            if (number % 2 == 0)
            {
                sum += number;
            }
        }
        return sum;
    }

    static void Main(string[] args)
    {
        // Thiết lập encoding để hiển thị tiếng Việt
        Console.OutputEncoding = Encoding.UTF8;

        int[] numbers = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };

        int result = SumEvenNumbers(numbers);

        Console.WriteLine("Mảng số: " + string.Join(", ", numbers));
        Console.WriteLine("Tổng các số chẵn trong mảng là: " + result);
    }
}*/

//B2: Viết chương trình nhập vào mảng gồm n phần tử nhập từ bàn phím. Viết hàm để kiểm tra xem một số có phải là số nguyên tố hay không, hiển thị chỉ số và giá trị của những phần tử là số nguyên tố trong mảng.
/*using System;
using System.Text; // Để sử dụng Encoding.UTF8
class Program
{
    static bool IsPrime(int number)
    {
        if (number <= 1) return false;
        for (int i = 2; i <= Math.Sqrt(number); i++)
        {
            if (number % i == 0) return false;
        }
        return true;
    }
    static void Main(string[] args)
    {
        // Thiết lập encoding để hiển thị tiếng Việt
        Console.OutputEncoding = Encoding.UTF8;
        Console.Write("Nhập số lượng phần tử của mảng: ");
        int n = int.Parse(Console.ReadLine() ?? "0");
        int[] arr = new int[n];
        Console.WriteLine("Nhập các phần tử của mảng:");
        for (int i = 0; i < n; i++)
        {
            Console.Write($"Phần tử {i + 1}: ");
            arr[i] = int.Parse(Console.ReadLine() ?? "0");
        }
        Console.WriteLine("Các số nguyên tố trong mảng là:");
        for (int i = 0; i < n; i++)
        {
            if (IsPrime(arr[i]))
            {
                Console.WriteLine($"Chỉ số: {i}, Giá trị: {arr[i]}");
            }
        }
    }
}*/

//B3: Viết một hàm để đếm số lượng số âm và số dương trong một mảng gồm n phần tử nhập từ bàn phím
/*using System;
using System.Text; // Để sử dụng Encoding.UTF8
class Program
{
    static void CountPositiveNegative(int[] arr, out int positiveCount, out int negativeCount)
    {
        positiveCount = 0;
        negativeCount = 0;
        foreach (int number in arr)
        {
            if (number > 0)
            {
                positiveCount++;
            }
            else if (number < 0)
            {
                negativeCount++;
            }
        }
    }
    static void Main(string[] args)
    {
        // Thiết lập encoding để hiển thị tiếng Việt
        Console.OutputEncoding = Encoding.UTF8;
        Console.Write("Nhập số lượng phần tử của mảng: ");
        int n = int.Parse(Console.ReadLine() ?? "0");
        int[] arr = new int[n];
        Console.WriteLine("Nhập các phần tử của mảng:");
        for (int i = 0; i < n; i++)
        {
            Console.Write($"Phần tử {i + 1}: ");
            arr[i] = int.Parse(Console.ReadLine() ?? "0");
        }
        CountPositiveNegative(arr, out int positiveCount, out int negativeCount);
        Console.WriteLine($"Số lượng số dương: {positiveCount}");
        Console.WriteLine($"Số lượng số âm: {negativeCount}");
    }
}*/

//B4: Viết hàm để tìm số lớn thứ hai trong một mảng các số nguyên.
/*using System;
using System.Text; // Để sử dụng Encoding.UTF8
class Program
{
    static int FindSecondLargest(int[] arr)
    {
        if (arr.Length < 2)
            throw new ArgumentException("Mảng phải có ít nhất hai phần tử.");

        int largest = int.MinValue;
        int secondLargest = int.MinValue;
        foreach (int number in arr)
        {
            if (number > largest)
            {
                secondLargest = largest;
                largest = number;
            }
            else if (number > secondLargest && number != largest)
            {
                secondLargest = number;
            }
        }
        if (secondLargest == int.MinValue)
            throw new InvalidOperationException("Không tìm thấy số lớn thứ hai trong mảng.");
        return secondLargest;
    }
    static void Main(string[] args)
    {
        // Thiết lập encoding để hiển thị tiếng Việt
        Console.OutputEncoding = Encoding.UTF8;
        Console.Write("Nhập số lượng phần tử của mảng: ");
        int n = int.Parse(Console.ReadLine() ?? "0");
        int[] arr = new int[n];
        Console.WriteLine("Nhập các phần tử của mảng:");
        for (int i = 0; i < n; i++)
        {
            Console.Write($"Phần tử {i + 1}: ");
            arr[i] = int.Parse(Console.ReadLine() ?? "0");
        }
        try
        {
            int secondLargest = FindSecondLargest(arr);
            Console.WriteLine($"Số lớn thứ hai trong mảng là: {secondLargest}");
        }
        catch (Exception ex)
        {
            Console.WriteLine("Lỗi: " + ex.Message);
        }
    }
}*/

//B5: Viết hàm hoán vị 2 số nguyên a và b nhập từ bàn phím.
/*using System;
using System.Text; // Để sử dụng Encoding.UTF8
class Program
{
    static void Swap(ref int a, ref int b)
    {
        int temp = a;
        a = b;
        b = temp;
    }
    static void Main(string[] args)
    {
        // Thiết lập encoding để hiển thị tiếng Việt
        Console.OutputEncoding = Encoding.UTF8;
        Console.Write("Nhập số nguyên a: ");
        int a = int.Parse(Console.ReadLine() ?? "0");
        Console.Write("Nhập số nguyên b: ");
        int b = int.Parse(Console.ReadLine() ?? "0");
        Console.WriteLine($"Trước khi hoán vị: a = {a}, b = {b}");
        Swap(ref a, ref b);
        Console.WriteLine($"Sau khi hoán vị: a = {a}, b = {b}");
    }
}*/

//B6: Viết hàm sắp xếp mảng số thực n phần tử nhập từ bàn phím theo chiều tăng dần.
/*using System;
using System.Text; // Để sử dụng Encoding.UTF8
class Program
{
    static void SortArray(float[] arr)
    {
        Array.Sort(arr);
    }
    static void Main(string[] args)
    {
        // Thiết lập encoding để hiển thị tiếng Việt
        Console.OutputEncoding = Encoding.UTF8;
        Console.Write("Nhập số lượng phần tử của mảng: ");
        int n = int.Parse(Console.ReadLine() ?? "0");
        float[] arr = new float[n];
        Console.WriteLine("Nhập các phần tử của mảng:");
        for (int i = 0; i < n; i++)
        {
            Console.Write($"Phần tử {i + 1}: ");
            arr[i] = float.Parse(Console.ReadLine() ?? "0");
        }
        SortArray(arr);
        Console.WriteLine("Mảng sau khi sắp xếp theo chiều tăng dần:");
        foreach (float number in arr)
        {
            Console.Write(number + " ");
        }
    }
}*/






