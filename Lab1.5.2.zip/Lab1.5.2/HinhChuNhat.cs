﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab1._5._2
{
    class HinhChuNhat : Hinh
    {
        private double dai, rong;

        public override void Nhap()
        {
            Console.Write("Nhập chiều dài: ");
            dai = double.Parse(Console.ReadLine());
            Console.Write("Nhập chiều rộng: ");
            rong = double.Parse(Console.ReadLine());
        }

        public override double TinhChuVi() => 2 * (dai + rong);
        public override double TinhDienTich() => dai * rong;
    }
}
