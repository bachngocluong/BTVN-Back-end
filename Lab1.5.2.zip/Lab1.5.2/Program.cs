﻿// Bach Ngoc Luong - CNTT1710
// Bai 1.5.2
//Bài 2: Xây dựng chương trình tính chu vi và diện tích hình tròn, vuông, tam giác, chữ nhật
//Gợi ý:
//-Tạo một lớp “Hinh” có phương thức ảo tính chu vi, diện tích
//- Tạo các lớp: “HinhTron”, “HinhVuong”, “HinhTamGiac”, “HinhChuNhat” kế thừa
//từ class “Hinh” và định nghĩa các hàm tính chu vi, diện tích
//- Tạo List chỉ các Hinh. Tính tổng chu vi và tổng diện tích các hình trong List

using Lab1._5._2;

Console.OutputEncoding = System.Text.Encoding.UTF8;
List<Hinh> danhSachHinh = new List<Hinh>();

// Nhập số lượng hình
Console.Write("Nhập số lượng hình: ");
int n = int.Parse(Console.ReadLine());

// Nhập thông tin các hình
for (int i = 0; i < n; i++)
{
    Console.WriteLine($"\nHình {i + 1}:");
    Console.Write("Chọn loại (1-Chữ nhật, 2-Tròn, 3-Vuông, 4-Tam giác): ");
    int loai = int.Parse(Console.ReadLine());

    Hinh hinh = loai switch
    {
        1 => new HinhChuNhat(),
        2 => new HinhTron(),
        3 => new HinhVuong(),
        4 => new HinhTamGiac(),
        _ => null
    };

    if (hinh == null)
    {
        Console.WriteLine("Loại hình không hợp lệ!");
        i--;
        continue;
    }

    hinh.Nhap();
    danhSachHinh.Add(hinh);
}

// Tính và hiển thị kết quả
double tongChuVi = 0, tongDienTich = 0;
Console.WriteLine("\nKết quả:");
for (int i = 0; i < danhSachHinh.Count; i++)
{
    var hinh = danhSachHinh[i];
    double chuVi = hinh.TinhChuVi();
    double dienTich = hinh.TinhDienTich();
    tongChuVi += chuVi;
    tongDienTich += dienTich;
    Console.WriteLine($"Hình {i + 1}: Chu vi = {chuVi:F2}, Diện tích = {dienTich:F2}");
}

Console.WriteLine($"\nTổng chu vi: {tongChuVi:F2}");
Console.WriteLine($"Tổng diện tích: {tongDienTich:F2}");
