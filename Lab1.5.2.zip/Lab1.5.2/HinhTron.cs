﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab1._5._2
{
    class HinhTron : Hinh
    {
        private double banKinh;

        public override void Nhap()
        {
            Console.Write("Nhập bán kính: ");
            banKinh = double.Parse(Console.ReadLine());
        }

        public override double TinhChuVi() => 2 * Math.PI * banKinh;
        public override double TinhDienTich() => Math.PI * banKinh * banKinh;
    }
}
