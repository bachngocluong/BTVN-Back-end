﻿using Microsoft.AspNetCore.Mvc;
using Lab03.Models;

namespace Lab03.Controllers
{
    public class ProductController : Controller
    {
        static List<Product> products = new List<Product>()
        {
            new Product {Id=1,Name="Máy lạnh",Price=5},
            new Product {Id=2,Name="Máy điều hòa",Price=6},
            new Product {Id=3,Name="TiVi",Price=3},
            new Product {Id=4,Name="Máy phóng xạ",Price=12},
            new Product {Id=5,Name="Máy rửa bát",Price=4},
        };
        public IActionResult Index()
        {
            return View(products);
        }
        public IActionResult Details()
        {
            return View();
        }
        public IActionResult Save(Product pro)
        {
            if (!ModelState.IsValid)
            {
                return View("Details", pro); // Trả lại form kèm dữ liệu và lỗi
            }
            products.Add(pro);
            return RedirectToAction("Index");
        }
    }
}
