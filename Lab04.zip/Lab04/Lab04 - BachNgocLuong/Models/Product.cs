﻿using System.ComponentModel.DataAnnotations;

namespace Lab03.Models
{
    public class Product
    {
        [Display(Name = "Mã sản phẩm")]
        [Required(ErrorMessage = "Không được để trống!")]
        [Range(1, 1000, ErrorMessage = "Mã sản phẩm phải nằm trong khoảng từ 1 đến 1000")]
        public int? Id { get; set; }

        [Display(Name = "Tên sản phẩm")]
        [Required(ErrorMessage = "Không được để trống!")]
        [MinLength(6, ErrorMessage = "Tên sản phẩm phải từ 6 đến 100 ký tự")]
        [MaxLength(100, ErrorMessage = "Tên sản phẩm phải từ 6 đến 100 ký tự")]
        public string? Name { get; set; }

        [Display(Name = "Giá sản phẩm")]
        [Required(ErrorMessage = "Không được để trống!")]
        [Range(0.01, double.MaxValue, ErrorMessage = "Giá phải lớn hơn 0")]
        public decimal? Price { get; set; }
    }
}
