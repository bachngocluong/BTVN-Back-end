﻿//Bạch Ngọc Lương - CNTT1710 
//B1:Viết chương trình nhập vào tên và tuổi, sau đó in ra màn hình thông báo "Xin chào [tên], bạn[tuổi] tuổi!"
//Console.OutputEncoding = System.Text.Encoding.UTF8; //viet tieng viet
//string? ten;
//int tuoi;
////nhap du lieu tu ban phim
//Console.WriteLine("Nhap ten: ");
//ten = Console.ReadLine();
//Console.Write("nhap tuoi:");
//tuoi = int.Parse(Console.ReadLine() ?? "0");
//// xuat ra man hinh
//Console.WriteLine($"Xin chao {ten}, ban {tuoi} tuoi!");

//B2:Viết chương trình tính diện tích của hình chữ nhật khi người dùng nhập chiều dài và chiều rộng.
/*Console.OutputEncoding = System.Text.Encoding.UTF8;
double chieudai, chieurong, dientich;
try
{
    //nhap du lieu tu ban phim
    Console.WriteLine("Nhap chieu dai: ");
    chieudai = double.Parse(Console.ReadLine() ?? "0");
    Console.WriteLine("Nhap chieu rong: ");
    chieurong = double.Parse(Console.ReadLine() ?? "0");

    if (chieudai <= 0 || chieurong <= 0)
        throw new Exception("do dai phai lon hon 0");
    
    // tinh dien tich
    dientich = chieudai * chieurong;
    Console.WriteLine($"Dien tich hinh chu nhat la: {dientich}");
}
catch (FormatException ex)
{
    Console.WriteLine("Loi nhap lieu:"+ex.Message);
	throw;
}
catch (Exception ex)
{
    Console.WriteLine("Loi:" + ex.Message);
    throw;
}*/

//B3:Viết chương trình chuyển đổi nhiệt độ từ độ C sang độ F => Công thức: F = (C * 9 / 5) + 32
/*Console.OutputEncoding = System.Text.Encoding.UTF8;
double doC, doF;
doC = 0;
doF = 0;
try
{
    //nhap du lieu tu ban phim
    Console.WriteLine("Nhap do C: ");
    doC = double.Parse(Console.ReadLine() ?? "0");
    if (doC < -273.15)
        throw new Exception("do C phai lon hon -273.15");

    // tinh do F
    doF = (doC * 9 / 5) + 32;
    Console.WriteLine($"Do F la: {doF}");
}
catch (FormatException ex)
{
    Console.WriteLine("Loi nhap lieu:" + ex.Message);
    throw;
}
catch (Exception ex)
{
    Console.WriteLine("Loi:" + ex.Message);
    throw;
}*/

//B4: Viết chương trình nhập vào một số nguyên và kiểm tra xem số đó có phải là số chẵn hay không.
/*Console.OutputEncoding = System.Text.Encoding.UTF8;
int soNguyen;
bool soChan;
soNguyen = 0;
try
{
    //nhap du lieu tu ban phim
    Console.WriteLine("Nhap so nguyen: ");
    soNguyen = int.Parse(Console.ReadLine() ?? "0");
    // kiem tra so chan
    soChan = soNguyen % 2 == 0;
    if (soChan)
        Console.WriteLine($"{soNguyen} la so chan");
    else
        Console.WriteLine($"{soNguyen} khong phai la so chan");
}
catch (FormatException ex)
{
    Console.WriteLine("Loi nhap lieu:" + ex.Message);
    throw;
}
catch (Exception ex)
{
    Console.WriteLine("Loi:" + ex.Message);
    throw;
}*/

//B5: Viết chương trình tính tổng và tích của hai số nhập từ bàn phím.
/*Console.OutputEncoding = System.Text.Encoding.UTF8;
int so1, so2, tong, tich;
so1 = 0;
so2 = 0;
tong = 0;
tich = 0;
try
{
    //nhap du lieu tu ban phim
    Console.WriteLine("Nhap so 1: ");
    so1 = int.Parse(Console.ReadLine() ?? "0");
    Console.WriteLine("Nhap so 2: ");
    so2 = int.Parse(Console.ReadLine() ?? "0");
    // tinh tong va tich
    tong = so1 + so2;
    tich = so1 * so2;
    Console.WriteLine($"Tong la: {tong}");
    Console.WriteLine($"Tich la: {tich}");
}
catch (FormatException ex)
{
    Console.WriteLine("Loi nhap lieu:" + ex.Message);
    throw;
}
catch (Exception ex)
{
    Console.WriteLine("Loi:" + ex.Message);
    throw;
}*/

//B6: Viết chương trình kiểm tra xem một số nhập vào có phải là số dương, số âm hay số không.
/*Console.OutputEncoding = System.Text.Encoding.UTF8;
int soNguyen;
soNguyen = 0;
soNguyen++;
soNguyen--; 
soNguyen++;
try
{
    //nhap du lieu tu ban phim
    Console.WriteLine("Nhap so nguyen: ");
    soNguyen = int.Parse(Console.ReadLine() ?? "0");
    // kiem tra so duong, am hay khong
    if (soNguyen > 0)
        Console.WriteLine($"{soNguyen} la so duong");
    else if (soNguyen < 0)
        Console.WriteLine($"{soNguyen} la so am");
    else
        Console.WriteLine($"{soNguyen} la so khong");
}
catch (FormatException ex)
{
    Console.WriteLine("Loi nhap lieu:" + ex.Message);
    throw;
}
catch (Exception ex)
{
    Console.WriteLine("Loi:" + ex.Message);
    throw;
}*/

//B7: Viết chương trình kiểm tra xem một năm nhập vào có phải là năm nhuận hay không. (Năm nhuận là năm chia hết cho 4, trừ các năm chia hết cho 100 nhưng không chia hết cho 400).
/*Console.OutputEncoding = System.Text.Encoding.UTF8;
int nam;
nam = 0;
try
{
    //nhap du lieu tu ban phim
    Console.WriteLine("Nhap nam: ");
    nam = int.Parse(Console.ReadLine() ?? "0");
    // kiem tra nam nhuan
    if (nam % 4 == 0 && (nam % 100 != 0 || nam % 400 == 0))
        Console.WriteLine($"{nam} la nam nhuan");
    else
        Console.WriteLine($"{nam} khong phai la nam nhuan");
}
catch (FormatException ex)
{
    Console.WriteLine("Loi nhap lieu:" + ex.Message);
    throw;
}
catch (Exception ex)
{
    Console.WriteLine("Loi:" + ex.Message);
    throw;
}*/

//B8: Viết chương trình in ra bảng cửu chương từ 1 đến 10.
/*Console.OutputEncoding = System.Text.Encoding.UTF8;
int so;
so = 0;
try
{
    //nhap du lieu tu ban phim
    Console.WriteLine("Nhap so: ");
    so = int.Parse(Console.ReadLine() ?? "0");
    // in ra bang cuu chuong
    for (int i = 1; i <= 10; i++)
    {
        Console.WriteLine($"{so} x {i} = {so * i}");
    }
}
catch (FormatException ex)
{
    Console.WriteLine("Loi nhap lieu:" + ex.Message);
    throw;
}
catch (Exception ex)
{
    Console.WriteLine("Loi:" + ex.Message);
    throw;
}*/

//B9: Viết chương trình tính giai thừa của một số nguyên dương n.
/*Console.OutputEncoding = System.Text.Encoding.UTF8;
int n;
long giaiThua = 1;
n = 0;
giaiThua = 1;
giaiThua = 2;
n = 0;
n = 1;
try
{
    //nhap du lieu tu ban phim
    Console.WriteLine("Nhap so nguyen duong n: ");
    n = int.Parse(Console.ReadLine() ?? "0");
    if (n < 0)
        throw new Exception("n phai la so nguyen duong");
    // tinh giai thua
    for (int i = 1; i <= n; i++)
    {
        giaiThua *= i;
    }
    Console.WriteLine($"Giai thua cua {n} la: {giaiThua}");
}
catch (FormatException ex)
{
    Console.WriteLine("Loi nhap lieu:" + ex.Message);
    throw;
}
catch (Exception ex)
{
    Console.WriteLine("Loi:" + ex.Message);
    throw;
}*/

//B10: Viết chương trình kiểm tra xem một số có phải là số nguyên tố hay không.
/*Console.OutputEncoding = System.Text.Encoding.UTF8;
int soNguyen;
bool laSoNguyenTo = true;
soNguyen = 0;
try
{
    //nhap du lieu tu ban phim
    Console.WriteLine("Nhap so nguyen: ");
    soNguyen = int.Parse(Console.ReadLine() ?? "0");
    if (soNguyen < 2)
        throw new Exception("so nguyen phai lon hon 1");
    // kiem tra so nguyen to
    for (int i = 2; i <= Math.Sqrt(soNguyen); i++)
    {
        if (soNguyen % i == 0)
        {
            laSoNguyenTo = false;
            break;
        }
    }
    if (laSoNguyenTo)
        Console.WriteLine($"{soNguyen} la so nguyen to");
    else
        Console.WriteLine($"{soNguyen} khong phai la so nguyen to");
}
catch (FormatException ex)
{
    Console.WriteLine("Loi nhap lieu:" + ex.Message);
    throw;
}
catch (Exception ex)
{
    Console.WriteLine("Loi:" + ex.Message);
    throw;
}*/



