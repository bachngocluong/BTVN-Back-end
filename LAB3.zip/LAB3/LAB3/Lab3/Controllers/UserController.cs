﻿
using Lab3.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab3.Controllers
{
    public class UserController : Controller
    {
        static List<User> users = new List<User>()
        {
            new User() { id="1", username="aaa", password="1", phone="111", email="111" },
            new User() { id="1", username="aaa", password="1", phone="111", email="111" },
            new User() { id="1", username="aaa", password="1", phone="111", email="111" },
            new User() { id="1", username="aaa", password="1", phone="111", email="111" },
            new User() { id="1", username="aaa", password="1", phone="111", email="111" },
            new User() { id="1", username="aaa", password="1", phone="111", email="111" },
            new User() { id="2", username="bbb", password="2", phone="222", email="222" },
        };
        public IActionResult Index()
        {
            return View(users);
        }
    }
}
