﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab1._3
{
    class Bao : TaiLieu
    {
        private DateTime ngayPhatHanh;
        public Bao() { }
        public Bao(string? maTL, string? tenNXB, int soBan, DateTime ngayPhatHanh) : base()
        {
            this.ngayPhatHanh = ngayPhatHanh;
        }
        public override void Nhap()
        {
            try
            {
                base.Nhap();
                Console.Write("+ Ngay phat hanh: ");
                ngayPhatHanh = DateTime.Parse(Console.ReadLine() ?? "0");
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        public override void Xuat()
        {
            base.Xuat();
            Console.WriteLine($"+ Ngay phat hanh: {ngayPhatHanh}");
        }
    }
}
