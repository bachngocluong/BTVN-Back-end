﻿// Bạch Ngọc Lương - CNTT1710 
using Lab1._3;

class QuanLyTaiLieu
{
    private List<TaiLieu> danhSachTaiLieu = new List<TaiLieu>();

    // Nhập thông tin tài liệu
    public void NhapThongTin()
    {
        Console.WriteLine("Chon loai tai lieu de nhap (1: Sach, 2: Tap chi, 3: Bao): ");
        string luaChon = Console.ReadLine();

        switch (luaChon)
        {
            case "1":
                Sach sach = new Sach();
                sach.Nhap();
                danhSachTaiLieu.Add(sach);
                break;
            case "2":
                TapChi tapChi = new TapChi();
                tapChi.Nhap();
                danhSachTaiLieu.Add(tapChi);
                break;
            case "3":
                Bao bao = new Bao();
                bao.Nhap();
                danhSachTaiLieu.Add(bao);
                break;
            default:
                Console.WriteLine("Lua chon khong hop le!");
                break;
        }
    }

    // Hiển thị thông tin tất cả tài liệu
    public void HienThiThongTin()
    {
        if (danhSachTaiLieu.Count == 0)
        {
            Console.WriteLine("Danh sach tai lieu trong!");
            return;
        }
        Console.WriteLine("\n=== DANH SACH TAI LIEU ===");
        foreach (var taiLieu in danhSachTaiLieu)
        {
            Console.WriteLine("-------------------");
            taiLieu.Xuat();
        }
    }

    // Tìm kiếm tài liệu theo loại
    public void TimKiemTheoLoai(string loai)
    {
        bool found = false;
        Console.WriteLine($"\n=== KET QUA TIM KIEM: {loai} ===");
        foreach (var taiLieu in danhSachTaiLieu)
        {
            if ((loai == "Sach" && taiLieu is Sach) ||
                (loai == "TapChi" && taiLieu is TapChi) ||
                (loai == "Bao" && taiLieu is Bao))
            {
                taiLieu.Xuat();
                Console.WriteLine("-------------------");
                found = true;
            }
        }
        if (!found)
            Console.WriteLine($"Khong tim thay tai lieu loai {loai}!");
    }

    // Chương trình chính
    static void Main(string[] args)
    {
        Console.OutputEncoding = System.Text.Encoding.UTF8;
        QuanLyTaiLieu ql = new QuanLyTaiLieu();
        while (true)
        {
            Console.WriteLine("\n=== QUAN LY THU VIEN ===");
            Console.WriteLine("1. Nhap thong tin tai lieu");
            Console.WriteLine("2. Hien thi thong tin tai lieu");
            Console.WriteLine("3. Tim kiem tai lieu theo loai");
            Console.WriteLine("4. Thoat");
            Console.Write("Chon chuc nang: ");
            string chon = Console.ReadLine();

            try
            {
                switch (chon)
                {
                    case "1":
                        ql.NhapThongTin();
                        break;
                    case "2":
                        ql.HienThiThongTin();
                        break;
                    case "3":
                        Console.Write("Nhap loai tai lieu (Sach/TapChi/Bao): ");
                        string loai = Console.ReadLine();
                        ql.TimKiemTheoLoai(loai);
                        break;
                    case "4":
                        Console.WriteLine("Tam biet!");
                        return;
                    default:
                        Console.WriteLine("Chuc nang khong hop le!");
                        break;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Loi: " + ex.Message);
            }
        }
    }
}

//B22: Nhập danh sách n học sinh viết dưới dạng các thuộc tính: họ tên, năm sinh và tổng
//điểm.Sắp xếp theo thứ tự giảm dần của tổng điểm. Khi tổng điểm như nhau thì học sinh có
//năm sinh nhỏ hơn được đứng trước. In ra danh sách học sinh đã sắp xếp sao cho tất cả các chữ
//cái đầu của họ tên chuyển thành chữ hoa.
/*using System;
using System.Collections.Generic;
using System.Linq;

class Student
{
    public string FullName { get; set; }
    public int BirthYear { get; set; }
    public double TotalScore { get; set; }

    // Constructor
    public Student(string fullName, int birthYear, double totalScore)
    {
        FullName = fullName;
        BirthYear = birthYear;
        TotalScore = totalScore;
    }

    // Phương thức chuyển chữ cái đầu thành chữ hoa
    public string GetFormattedName()
    {
        string[] words = FullName.Split(' ');
        for (int i = 0; i < words.Length; i++)
        {
            if (words[i].Length > 0)
            {
                words[i] = char.ToUpper(words[i][0]) + words[i].Substring(1).ToLower();
            }
        }
        return string.Join(" ", words);
    }
}

class Program
{
    static void Main(string[] args)
    {
        Console.Write("Nhap so luong hoc sinh: ");
        int n = int.Parse(Console.ReadLine());

        List<Student> students = new List<Student>();

        // Nhập thông tin học sinh
        for (int i = 0; i < n; i++)
        {
            Console.WriteLine($"\nNhap thong tin hoc sinh thu {i + 1}:");

            Console.Write("Ho ten: ");
            string fullName = Console.ReadLine();

            Console.Write("Nam sinh: ");
            int birthYear = int.Parse(Console.ReadLine());

            Console.Write("Tong diem: ");
            double totalScore = double.Parse(Console.ReadLine());

            students.Add(new Student(fullName, birthYear, totalScore));
        }

        // Sắp xếp danh sách
        var sortedStudents = students.OrderByDescending(s => s.TotalScore)
                                   .ThenBy(s => s.BirthYear)
                                   .ToList();

        // In danh sách đã sắp xếp
        Console.WriteLine("\nDanh sach hoc sinh sau khi sap xep:");
        Console.WriteLine("STT  Ho Ten               Nam Sinh  Tong Diem");
        Console.WriteLine("--------------------------------------------");

        for (int i = 0; i < sortedStudents.Count; i++)
        {
            Console.WriteLine($"{i + 1,-4} {sortedStudents[i].GetFormattedName(),-20} " +
                            $"{sortedStudents[i].BirthYear,-9} {sortedStudents[i].TotalScore}");
        }
    }
}
*/