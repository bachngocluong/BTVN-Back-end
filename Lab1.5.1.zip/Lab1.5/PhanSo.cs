﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab1._5
{
    class PhanSo
    {
        public Double TuSo { get; set; }
        public Double MauSo { get; set; }
        public PhanSo() { }
        public PhanSo(double tuSo, double mauSo)
        {
            TuSo = tuSo;
            MauSo = mauSo != 0 ? mauSo : throw new ArgumentException("Mẫu số không được bằng 0");
        }

        public void NhapPhanSo()
        {
            Console.Write("Nhập tử số: ");
            TuSo = double.Parse(Console.ReadLine());

            do
            {
                Console.Write("Nhập mẫu số (khác 0): ");
                MauSo = double.Parse(Console.ReadLine());
                if (MauSo == 0)
                    Console.WriteLine("Mẫu số không được bằng 0!");
            } while (MauSo == 0);
        }

        // Phương thức cộng hai phân số
        public static PhanSo Cong(PhanSo ps1, PhanSo ps2)
        {
            double tu = ps1.TuSo * ps2.MauSo + ps2.TuSo * ps1.MauSo;
            double mau = ps1.MauSo * ps2.MauSo;
            return RutGon(new PhanSo(tu, mau));
        }

        // Phương thức rút gọn phân số
        private static PhanSo RutGon(PhanSo ps)
        {
            double ucln = UCLN(Math.Abs(ps.TuSo), Math.Abs(ps.MauSo));
            return new PhanSo(ps.TuSo / ucln, ps.MauSo / ucln);
        }

        // Tìm ước chung lớn nhất (UCLN) cho số thực
        private static double UCLN(double a, double b)
        {
            const double epsilon = 1e-10; // Độ chính xác cho số thực
            while (Math.Abs(b) > epsilon)
            {
                double temp = b;
                b = a % b;
                a = temp;
            }
            return Math.Abs(a);
        }

        // Phương thức hiển thị phân số
        public void HienThi()
        {
            Console.WriteLine($"{TuSo:F2}/{MauSo:F2}");
        }
    }
}
